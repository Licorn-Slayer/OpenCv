import cv2 as cv

img = cv.imread("1.jpeg")
cv.imshow("1",img)

cv.waitKey(0)